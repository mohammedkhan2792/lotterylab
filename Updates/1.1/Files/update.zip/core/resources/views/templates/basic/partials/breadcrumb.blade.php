<div class="pt-70 breadcrumb">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12">
                <h2 class="mb-0">{{ __($pageTitle) }}</h2>
            </div>
        </div>
    </div>
</div>
